package paquete;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Plaga {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idplaga;
	private String nombreV;
	private String nombreC;
	private String url;
	@ManyToMany
    @JoinTable(name = "plaga_sustancia", 
             joinColumns = { @JoinColumn(name = "idplaga" )}, 
             inverseJoinColumns = { @JoinColumn(name = "idsustancia") })
    private List<Sustancia> sustancias;
	public Plaga() {
		
	}
	public Plaga(String nombre_vulgar, String nombre_cientifico, String url, List<Sustancia> sustancia) {
		this.nombreV = nombre_vulgar;
		this.nombreC = nombre_cientifico;
		this.url = url;
		this.sustancias = sustancia;
	}
	public String getNombreV() {
		return nombreV;
	}
	public void setNombreV(String nombre_vulgar) {
		this.nombreV = nombre_vulgar;
	}
	public String getNombreC() {
		return nombreC;
	}
	public void setNombreC(String nombre_cientifico) {
		this.nombreC = nombre_cientifico;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public List<Sustancia> getSustancias() {
		return sustancias;
	}
	public void setSustancias(List<Sustancia> sustancia) {
		this.sustancias = sustancia;
	}
	
}
