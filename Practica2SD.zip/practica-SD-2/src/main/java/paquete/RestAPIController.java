package paquete;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;




@RestController
public class RestAPIController {
	@Autowired
	private Service service;
	@RequestMapping(value = "/cultivos", method = RequestMethod.GET)
	public List<Cultivo> getCultivos() {
		return service.getCultivos();
	}
	@RequestMapping(value = "/cultivo/{idcultivo}", method = RequestMethod.GET)
	public Cultivo getCultivo(@PathVariable("idcultivo") String nombre) {
		return service.getCultivo(nombre);
	}
	@RequestMapping(value = "/especie/{especie}", method = RequestMethod.GET)
	public Especie getEspecie(@PathVariable("especie") String nombre) {
		return service.getEspecie(nombre);
	}
	@RequestMapping(value = "/plaga/{plaga}", method = RequestMethod.GET)
	public Plaga getPlaga(@PathVariable("plaga") String nombre) {
		return service.getPlaga(nombre);
	}
	@RequestMapping(value = "/sustancia/{sustancia}", method = RequestMethod.GET)
	public Sustancia getSustancia(@PathVariable("sustancia") String nombre) {
		return service.getSustancia(nombre);
	}
}
