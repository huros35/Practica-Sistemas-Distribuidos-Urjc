package paquete;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.JoinColumn;

@Entity
public class Cultivo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idcultivo;
	private String nombre;
	@ManyToMany
    @JoinTable(name = "CULTIVO_ESPECIE", 
             joinColumns = { @JoinColumn(name = "idcultivo" )}, 
             inverseJoinColumns = { @JoinColumn(name = "idespecie") })
    private List<Especie> especies;
	public Cultivo() {
		
	}
	public Cultivo(String nombre, List<Especie> especies) {
		this.nombre = nombre;
		this.especies = especies;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public List<Especie> getEspecies() {
		return especies;
	}
	public void setEspecies(List<Especie> especies) {
		this.especies = especies;
	}
	
 
}
