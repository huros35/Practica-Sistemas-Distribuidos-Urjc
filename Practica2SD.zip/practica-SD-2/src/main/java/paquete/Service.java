package paquete;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;





@Component
public class Service {
	@Autowired
	private CultivoRepository repositorioCultivos;
	@Autowired
	private EspecieRepository repositorioEspecies;
	@Autowired
	private PlagaRepository repositorioPlagas;
	@Autowired
	private ProductoRepository repositorioProductos;
	@Autowired
	private SustanciaRepository repositorioSustancias;
	@PostConstruct
	public void init() {
		/*
		List<Producto> lista_pr=new ArrayList<Producto>();
		Producto pr=new Producto("producto","prod");
		lista_pr.add(pr);
		repositorioProductos.save(pr);
		List<Sustancia> lista_su=new ArrayList<Sustancia>();
		Sustancia su=new Sustancia("sustancia",lista_pr);
		lista_su.add(su);
		repositorioSustancias.save(su);
		List<Plaga> lista_p=new ArrayList<Plaga>();
		Plaga p=new Plaga("Plaga","P12","as",lista_su);
		lista_p.add(p);
		repositorioPlagas.save(p);
		Especie e1=new Especie("Fresa","Fresilla",lista_p);
		Especie e2=new Especie("Manzana","Apple",new ArrayList<Plaga>());
		
		repositorioEspecies.save(e1);
		repositorioEspecies.save(e2);
		List<Especie> lista_e=new ArrayList<Especie>();
		lista_e.add(e1);
		Cultivo c1=new Cultivo("Cultivo 1",lista_e);
		repositorioCultivos.save(c1);
		List<Especie> lista_e1=new ArrayList<Especie>();
		lista_e1.add(e2);
		Cultivo c2=new Cultivo("Cultivo 2",lista_e1);
		repositorioCultivos.save(c2);
		*/
		List<Producto> lista_pr=new ArrayList<Producto>();
		for(int i=0;i<30;i++) {
			Producto pr=new Producto("producto "+ i,"prod" + i);
			lista_pr.add(pr);
			repositorioProductos.save(pr);
		}
		List<Sustancia> lista_su=new ArrayList<Sustancia>();
		for (int i=0;i<20;i++) {
			Sustancia su=new Sustancia("sustancia "+i,new ArrayList<Producto>());
			lista_su.add(su);
		}
		for (int i=0;i<30;i++) {
			lista_su.get(i%20).getProductos().add(lista_pr.get(i));
		}
			repositorioSustancias.saveAll(lista_su);
		List<Plaga> lista_p=new ArrayList<Plaga>();
		for(int i=0;i<16;i++) {
			Plaga p=new Plaga("Plaga "+i,"P "+i,"URL"+i,new ArrayList<Sustancia>());
			lista_p.add(p);
		}
		for (int i=0;i<20;i++) {
			lista_p.get(i%16).getSustancias().add(lista_su.get(i));
		}
		lista_p.get(1).getSustancias().add(lista_su.get(1));
		lista_p.get(2).getSustancias().add(lista_su.get(1));
		lista_p.get(3).getSustancias().add(lista_su.get(1));
		lista_p.get(4).getSustancias().add(lista_su.get(2));
		lista_p.get(5).getSustancias().add(lista_su.get(2));
		lista_p.get(6).getSustancias().add(lista_su.get(2));
		lista_p.get(7).getSustancias().add(lista_su.get(3));
		lista_p.get(8).getSustancias().add(lista_su.get(3));
		lista_p.get(9).getSustancias().add(lista_su.get(4));
		lista_p.get(10).getSustancias().add(lista_su.get(4));
		lista_p.get(11).getSustancias().add(lista_su.get(5));
		lista_p.get(12).getSustancias().add(lista_su.get(5));
		lista_p.get(13).getSustancias().add(lista_su.get(6));
		lista_p.get(14).getSustancias().add(lista_su.get(6));
		repositorioPlagas.saveAll(lista_p);
		List<Especie> lista_e=new ArrayList<Especie>();
		for (int i=0;i<8;i++) {
			Especie e=new Especie("Especie "+i,"E: "+i,new ArrayList<Plaga>());
			lista_e.add(e);
		}
		for (int i=0;i<16;i++) {
			lista_e.get(i%8).getPlagas().add(lista_p.get(i));
		}
		lista_e.get(1).getPlagas().add(lista_p.get(7));
		lista_e.get(2).getPlagas().add(lista_p.get(7));
		lista_e.get(3).getPlagas().add(lista_p.get(7));
		lista_e.get(4).getPlagas().add(lista_p.get(10));
		lista_e.get(5).getPlagas().add(lista_p.get(10));
		lista_e.get(6).getPlagas().add(lista_p.get(11));
		lista_e.get(7).getPlagas().add(lista_p.get(11));
		repositorioEspecies.saveAll(lista_e);
		List<Cultivo> lista_c=new ArrayList<Cultivo>();
		for (int i=0;i<4;i++) {
			Cultivo c=new Cultivo("Cultivo "+i,new ArrayList<Especie>());
			lista_c.add(c);
		}
		for (int i=0;i<8;i++) {
			lista_c.get(i%4).getEspecies().add(lista_e.get(i));
		}
		lista_c.get(1).getEspecies().add(lista_e.get(7));
		lista_c.get(2).getEspecies().add(lista_e.get(7));
		repositorioCultivos.saveAll(lista_c);
	}
	public Cultivo getCultivo(String nombre) {
		Cultivo c=repositorioCultivos.findByNombre(nombre);
		for (Especie especie : c.getEspecies()) {
			especie.setPlagas(null);
		}
		return c;
	}

public Especie getEspecie(String nombre) {
	Especie e=repositorioEspecies.findByNombreV(nombre);
	for (Plaga p : e.getPlagas()) {
		p.setSustancias(null);
	}
	return e;
}
public Plaga getPlaga(String nombre) {
	Plaga p=repositorioPlagas.findByNombreV(nombre);
	for (Sustancia s : p.getSustancias()) {
		s.setProductos(null);
	}
	return p;
}
public Sustancia getSustancia(String nombre) {
	Sustancia s=repositorioSustancias.findByNombre(nombre);
	return s;
}
	public List<Cultivo> getCultivos() {
		List<Cultivo> lista=repositorioCultivos.findAll();
		for (Cultivo cultivo : lista) {
			cultivo.setEspecies(null);
		}
		return lista;
	}
}
