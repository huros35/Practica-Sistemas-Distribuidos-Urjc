package paquete;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Especie {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idespecie;
	private String nombreV;
	private String nombreC;
	@ManyToMany
    @JoinTable(name = "especie_plaga", 
             joinColumns = { @JoinColumn(name = "idespecie" )}, 
             inverseJoinColumns = { @JoinColumn(name = "idplaga") })
    private List<Plaga> plagas;
	
	public Especie() {
	}
	public Especie(String nombre_vulgar, String nombre_cientifico, List<Plaga> plagas) {
		this.nombreV = nombre_vulgar;
		this.nombreC = nombre_cientifico;
		this.plagas = plagas;
	}
	public String getNombreV() {
		return nombreV;
	}
	public void setNombreV(String nombre_vulgar) {
		this.nombreV = nombre_vulgar;
	}
	public String getNombreC() {
		return nombreC;
	}
	public void setNombreC(String nombre_cientifico) {
		this.nombreC = nombre_cientifico;
	}
	public List<Plaga> getPlagas() {
		return plagas;
	}
	public void setPlagas(List<Plaga> plagas) {
		this.plagas = plagas;
	}
	
}
