package paquete;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SustanciaRepository extends JpaRepository<Sustancia, Long>{
	Sustancia findByNombre(String nombre);
}