package paquete;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
@Entity
public class Sustancia {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idsustancia;
	private String nombre;
	
	@ManyToMany
    @JoinTable(name = "sustancia_producto", 
             joinColumns = { @JoinColumn(name = "idsustancia" )}, 
             inverseJoinColumns = { @JoinColumn(name = "idproducto") })
    private List<Producto> productos;
	public Sustancia() {
		
	}
	public Sustancia(String nombre, List<Producto> productos) {
		this.nombre = nombre;
		this.productos = productos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}
	
}
