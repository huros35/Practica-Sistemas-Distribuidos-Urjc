package paquete;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PlagaRepository extends JpaRepository<Plaga, Long>{
	Plaga findByNombreV(String nombre);
}