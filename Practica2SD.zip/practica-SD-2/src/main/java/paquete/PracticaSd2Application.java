package paquete;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaSd2Application {

	public static void main(String[] args) {
		SpringApplication.run(PracticaSd2Application.class, args);
	}

}
