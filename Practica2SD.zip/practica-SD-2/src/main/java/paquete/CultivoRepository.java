package paquete;

import org.springframework.data.jpa.repository.JpaRepository;


public interface CultivoRepository extends JpaRepository<Cultivo, Long> {
	Cultivo findByNombre(String nombre);
}