$(function() {

var urlcultivo='http://localhost:8080/cultivos';

$.getJSON(urlcultivo,

     function(respuesta) {
        lista =$('#listaCultivos');
        $.each(respuesta, function(index,cultivo) {
        	var cultivohtml=$('<li/>').html(cultivo.nombre);
        	var button = $('<button/>',
        		    {	
        		        text: "Ampliar",
        		        click: especies
        		    });
        	button.data("nombre",cultivo.nombre)
        	cultivohtml.append(button);
        	lista.append(cultivohtml);
        	
        });
  });
function especies(){
	if($(this).next().is("ul")){
		$(this).next().remove()
		$(this).html("Ampliar")
	}else{
		var listespecie=$('<ul/>');
		$.getJSON('http://localhost:8080/cultivo/'+$(this).data("nombre"),

			     function(respuesta) {
			$.each(respuesta.especies, function(index,especie) {
	    		var especiehtml=$('<li/>');
	    		var especiename=$('<div/>').html(especie.nombreV);
	    		
	    		especiename.easyTooltip({
	    			tooltipDir: "left",
	    			content: especie.nombreC
	    		});
	    		
	    		var button = $('<button/>',
	        		    {	
	        		        text: "Ampliar",
	        		        click: plagas
	        		    });
	    		button.data("nombre",especie.nombreV)
	    		especiehtml.append(especiename);
	    		especiehtml.append(button);
	    		listespecie.append(especiehtml);
	    	});
		});
    	
    	$(this).parent().append(listespecie);
    	$(this).html("Comprimir");
	}
	
	
}
function plagas(){
	if($(this).next().is("ul")){
		$(this).next().remove()
		$(this).html("Ampliar")
	}else{
		var listplaga=$('<ul/>');
		$.getJSON('http://localhost:8080/especie/'+$(this).data("nombre"),

			     function(respuesta) {
			$.each(respuesta.plagas, function(index,plaga) {
	    		var plagahtml=$('<li/>');
	    		var plaganame=$('<div/>').html(plaga.nombreV);
	    		var plagaurl=$('<div/>').html(plaga.url);
	    		plaganame.easyTooltip({
	    			tooltipDir: "left",
	    			content:plaga.nombreC
	    		});
	    		var button = $('<button/>',
	        		    {	
	        		        text: "Ampliar",
	        		        click: sustancias
	        		    });
	    		button.data("nombre",plaga.nombreV)
	    		plagahtml.append(plaganame);
	    		plagahtml.append(plagaurl);
	    		plagahtml.append(button);
	    		listplaga.append(plagahtml);
	    	});
		});
    	
    	$(this).parent().append(listplaga);
    	$(this).html("Comprimir");
	}
}
function sustancias(){
	if($(this).next().is("ul")){
		$(this).next().remove()
		$(this).html("Ampliar")
	}else{
		var listsustancia=$('<ul/>');
		$.getJSON('http://localhost:8080/plaga/'+$(this).data("nombre"),

			     function(respuesta) {
			$.each(respuesta.sustancias, function(index,sustancia) {
	    		var sustanciahtml=$('<li/>');
	    		var sustancianame=$('<div/>').html(sustancia.nombre);
	    		var button = $('<button/>',
	        		    {	
	        		        text: "Ampliar",
	        		        click: productos	
	        		    });
	    		button.data("nombre",sustancia.nombre)
	    		sustanciahtml.append(sustancianame);
	    		sustanciahtml.append(button);
	    		listsustancia.append(sustanciahtml);
	    	});
		});
    	
    	$(this).parent().append(listsustancia);
    	$(this).html("Comprimir");
	}
}
function productos(){
	if($(this).next().is("ul")){
		$(this).next().remove()
		$(this).html("Ampliar")
	}else{
		var listproducto=$('<ul/>');
		$.getJSON('http://localhost:8080/sustancia/'+$(this).data("nombre"),

			     function(respuesta) {
			$.each(respuesta.productos, function(index,producto) {
	    		var productohtml=$('<li/>');
	    		var productoname=$('<div/>').html(producto.nombre);
	    		var productourl=$('<div/>').html(producto.url);
	    		productohtml.append(productoname);
	    		productohtml.append(productourl);
	    		listproducto.append(productohtml);
	    	});
		});
    	
    	$(this).parent().append(listproducto);
    	$(this).html("Comprimir");
	}
}

});
