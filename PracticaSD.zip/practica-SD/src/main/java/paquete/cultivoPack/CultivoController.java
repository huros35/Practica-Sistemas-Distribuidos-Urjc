package paquete.cultivoPack;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class CultivoController {
@Autowired
private CultivoRepository repositorioCultivos;

@RequestMapping("/insertarCultivo")
public String insertar(Cultivo cultivo,Model model) {
	repositorioCultivos.save(cultivo);

	return "cultivos/insertarCultivo";

}
@RequestMapping("/modificarCultivo")
public String modificar(@RequestParam long idcultivo,Cultivo cultivo, Model model) {
	Cultivo c = repositorioCultivos.getOne(idcultivo);
	c.updateCultivo(cultivo);
	repositorioCultivos.save(c);

	return "cultivos/modificarCultivo";
}

@RequestMapping("/actualizarCultivo")
public String actualizar(@RequestParam long idcultivo,
					   Model model) {
	Cultivo c = repositorioCultivos.getOne(idcultivo);
	model.addAttribute("cultivo",c);

	return "cultivos/actualizarCultivo";
}
@RequestMapping("/mostrarCultivos")
public String mostrar(  Model model) {
	
	List<Cultivo> listacultivos = repositorioCultivos.findAll();

    model.addAttribute("cultivos", listacultivos);
	

	return "cultivos/mostrarCultivos";
}
@RequestMapping("/buscarCultivo")
public String buscar( @RequestParam String consulta,@RequestParam String buscar, Model model) {
	List<Cultivo> listacultivos = null ;
	if (consulta.equals("especie")){
		listacultivos = repositorioCultivos.findByEspecie(buscar);
    }else if(consulta.equals("variedad")) {
    	listacultivos = repositorioCultivos.findByVariedad(buscar);

        	
    }else {
    	listacultivos = repositorioCultivos.findByFecha(LocalDate.parse(buscar));
    }
	
	model.addAttribute("cultivos", listacultivos);
	return "cultivos/mostrarCultivos";
}
}
