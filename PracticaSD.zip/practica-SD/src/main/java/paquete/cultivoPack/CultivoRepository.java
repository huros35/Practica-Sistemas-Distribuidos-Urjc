package paquete.cultivoPack;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface CultivoRepository extends JpaRepository<Cultivo, Long>{
		
	List<Cultivo> findByEspecie(String especie);
	List<Cultivo> findByVariedad(String variedad);
	List<Cultivo> findByFecha(LocalDate fecha);
	}