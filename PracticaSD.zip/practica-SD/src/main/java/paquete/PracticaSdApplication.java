package paquete;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaSdApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticaSdApplication.class, args);
	}

}
