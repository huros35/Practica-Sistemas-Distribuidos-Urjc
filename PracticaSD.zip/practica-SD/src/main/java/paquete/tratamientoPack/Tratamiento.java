package paquete.tratamientoPack;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import paquete.cultivoPack.Cultivo;
import paquete.prodFitoPack.Producto;


@Entity
public class Tratamiento {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long idtratamiento;
	@ManyToOne
	@JoinColumn(name = "idcultivo")
 	private Cultivo cultivo;
	@ManyToOne
	@JoinColumn(name = "idproducto")
 	private Producto producto;
	private String lote;
	private LocalDate fecha;
	private LocalDate reentrada;
	private LocalDate recoleccion;
	public Tratamiento() {
		
	}
	
	public Tratamiento(Cultivo cultivo, Producto producto, String lote, LocalDate tratamiento) {
		this.cultivo = cultivo;
		this.producto = producto;
		this.lote = lote;
		this.fecha = tratamiento;
		this.reentrada = tratamiento.plusDays(producto.getReentrada());
		this.recoleccion = tratamiento.plusDays(producto.getRecoleccion());
	}

	public void updateTratamiento(Tratamiento t) {
		this.lote = t.lote;
		this.fecha = t.fecha;

	}
	
	public long getIdtratamiento() {
		return idtratamiento;
	}

	public Cultivo getCultivo() {
		return cultivo;
	}
	public void setCultivo(Cultivo cultivo) {
		this.cultivo = cultivo;
	}
	public Producto getProducto() {
		return producto;
	}
	public void setProducto(Producto producto) {
		this.producto = producto;
		this.reentrada = fecha.plusDays(producto.getReentrada());
		this.recoleccion = fecha.plusDays(producto.getRecoleccion());
	}
	public String getLote() {
		return lote;
	}
	public void setLote(String lote) {
		this.lote = lote;
	}
	
	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = LocalDate.parse(fecha);
	}

	public LocalDate getReentrada() {
		return reentrada;
	}
	public void setReentrada(LocalDate reentrada) {
		this.reentrada = reentrada;
	}
	public LocalDate getRecoleccion() {
		return recoleccion;
	}
	public void setRecoleccion(LocalDate recoleccion) {
		this.recoleccion = recoleccion;
	}
	
}
