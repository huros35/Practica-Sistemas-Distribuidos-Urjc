package paquete.tratamientoPack;

import java.time.LocalDate;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import paquete.cultivoPack.Cultivo;
import paquete.cultivoPack.CultivoRepository;
import paquete.prodFitoPack.ProdFitoRepository;
import paquete.prodFitoPack.Producto;

@Controller
public class TratamientoController {
	@Autowired
	private TratamientoRepository repositorioTratamientos;
	@Autowired
	private ProdFitoRepository repositorioProductos;
	@Autowired
	private CultivoRepository repositorioCultivos;
	@PostConstruct
	public void init() {
		Producto p1= new Producto("Prod 1","este es el prod 1",3,10);
	    repositorioProductos.save(p1); 
	    Producto p2= new Producto("Prod 2","este es el prod 2",2,2);
	    repositorioProductos.save(p2);
	    Producto p3= new Producto("Prod 3","este es el prod 3",1,5);
	    repositorioProductos.save(p3);
	    Producto p4= new Producto("Prod 4","este es el prod 4",0,5);
	    repositorioProductos.save(p4);
	    Producto p5= new Producto("Prod 5","este es el prod 5",0,0);
	    repositorioProductos.save(p5);
		Cultivo c1 = new Cultivo("Cultivo 1","Variedad 1",LocalDate.parse("2021-01-01"),"A1");
		repositorioCultivos.save(c1);
		Cultivo c2 = new Cultivo("Cultivo 2","Variedad 2",LocalDate.parse("2021-01-01"),"A1");
		repositorioCultivos.save(c2);
		Cultivo c3 = new Cultivo("Cultivo 3","Variedad 3",LocalDate.parse("2021-01-01"),"A1");
		repositorioCultivos.save(c3);
		Cultivo c4 = new Cultivo("Cultivo 4","Variedad 4",LocalDate.parse("2021-01-01"),"A1");
		repositorioCultivos.save(c4);
		Cultivo c5 = new Cultivo("Cultivo 5","Variedad 5",LocalDate.parse("2021-01-01"),"A1");
		repositorioCultivos.save(c5);
		Cultivo c6 = new Cultivo("Cultivo 6","Variedad 6",LocalDate.parse("2021-01-01"),"A1");
		repositorioCultivos.save(c6);
		Tratamiento t1= new Tratamiento(c1,p1,"A12",LocalDate.parse("2021-01-01"));
	    repositorioTratamientos.save(t1);
	    Tratamiento t2= new Tratamiento(c1,p2,"B23",LocalDate.parse("2021-01-01"));
	    repositorioTratamientos.save(t2);
	    Tratamiento t3= new Tratamiento(c1,p4,"E65",LocalDate.parse("2021-01-01"));
	    repositorioTratamientos.save(t3); 
	    Tratamiento t4= new Tratamiento(c2,p2,"4S",LocalDate.parse("2021-01-02"));
	    repositorioTratamientos.save(t4);  
	    Tratamiento t5= new Tratamiento(c2,p3,"56T",LocalDate.parse("2021-01-03"));
	    repositorioTratamientos.save(t5);
	    Tratamiento t6= new Tratamiento(c3,p1,"89JK",LocalDate.parse("2021-01-04"));
	    repositorioTratamientos.save(t6);
	    Tratamiento t7= new Tratamiento(c4,p4,"Q34",LocalDate.parse("2021-01-02"));
	    repositorioTratamientos.save(t7);
	    Tratamiento t8= new Tratamiento(c5,p5,"WOI0",LocalDate.parse("2021-01-02"));
	    repositorioTratamientos.save(t8);
	}
	@RequestMapping("/nuevoTratamiento")
	public String insertar( Model model) {
		
		List<Cultivo> cultivos =repositorioCultivos.findAll();
		List<Producto> productos=repositorioProductos.findAll();
		
		model.addAttribute("cultivos", cultivos);
		model.addAttribute("productos", productos);
		
		return("tratamientos/nuevoTratamiento");
	}
	@RequestMapping("/insertarTratamiento")
	public String insertar(@RequestParam long idproducto, @RequestParam long idcultivo,Tratamiento tratamiento,
     	Model model) {
		Producto p = repositorioProductos.getOne(idproducto);
		tratamiento.setProducto(p);
		Cultivo c = repositorioCultivos.getOne(idcultivo);
		tratamiento.setCultivo(c);
		repositorioTratamientos.save(tratamiento);
		return "tratamientos/insertarTratamiento";
	}
	@RequestMapping("/modificarTratamiento")
	public String modificar(@RequestParam long idproducto, @RequestParam long idcultivo,@RequestParam long idtratamiento,Tratamiento tratamiento,
     	Model model) {
		Tratamiento t = repositorioTratamientos.getOne(idtratamiento);
		Producto p = repositorioProductos.getOne(idproducto);
		t.setProducto(p);
		Cultivo c = repositorioCultivos.getOne(idcultivo);
		t.setCultivo(c);
		t.updateTratamiento(tratamiento);
		t.setProducto(p);
		repositorioTratamientos.save(t);

		return "tratamientos/modificarTratamiento";
	}
	@RequestMapping("/actualizarTratamiento")
	public String actualizar(@RequestParam long idtratamiento,
						   Model model) {
		Tratamiento t = repositorioTratamientos.getOne(idtratamiento);
		model.addAttribute("tratamiento",t);
		List<Cultivo> cultivos =repositorioCultivos.findAll();
		List<Producto> productos=repositorioProductos.findAll();
		
		model.addAttribute("cultivos", cultivos);
		model.addAttribute("productos", productos);

		return "tratamientos/actualizarTratamiento";
	}
	@RequestMapping("/mostrarTratamientos")
	public String mostrar(  Model model) {
		
		List<Tratamiento> listatratamientos = repositorioTratamientos.findAll();

	    model.addAttribute("tratamientos", listatratamientos);
		

		return "tratamientos/mostrarTratamientos";
	}
	@RequestMapping("/buscarTratamiento")
	public String buscar( @RequestParam String consulta,@RequestParam String buscar, Model model) {
		List<Tratamiento> listatratamientos = null ;
		if (consulta.equals("cultivo")){
			listatratamientos = repositorioTratamientos.findByCultivoEspecie(buscar);
	    }else if(consulta.equals("producto")) {
	    	listatratamientos= repositorioTratamientos.findByProductoNombre(buscar);

	        	
	    }else if(consulta.equals("tratamiento")){
	    	listatratamientos= repositorioTratamientos.findByFecha(LocalDate.parse(buscar));
	    }
		
		model.addAttribute("tratamientos",listatratamientos);
		return "tratamientos/mostrarTratamientos";
	}
	@RequestMapping("/PlazoSeguridad")
	public String plazo( @RequestParam String consulta,@RequestParam String buscar, Model model) {
		List<Tratamiento> listatratamientos = null ;
		if (consulta.equals("especie")){
			listatratamientos = repositorioTratamientos.findByFechaLessThanEqualAndReentradaGreaterThanEqualOrFechaLessThanEqualAndRecoleccionGreaterThanEqualOrderByCultivoEspecie(LocalDate.parse(buscar),LocalDate.parse(buscar),LocalDate.parse(buscar),LocalDate.parse(buscar));
	    }else if(consulta.equals("reentrada")) {
	    	listatratamientos= repositorioTratamientos.findByFechaLessThanEqualAndReentradaGreaterThanEqualOrFechaLessThanEqualAndRecoleccionGreaterThanEqualOrderByReentrada(LocalDate.parse(buscar),LocalDate.parse(buscar),LocalDate.parse(buscar),LocalDate.parse(buscar));
	    }else {
	    	listatratamientos= repositorioTratamientos.findByFechaLessThanEqualAndReentradaGreaterThanEqualOrFechaLessThanEqualAndRecoleccionGreaterThanEqualOrderByRecoleccion(LocalDate.parse(buscar),LocalDate.parse(buscar),LocalDate.parse(buscar),LocalDate.parse(buscar));
	    }
		model.addAttribute("tratamientos",listatratamientos);
		return "tratamientos/mostrarTratamientos";
		
	}
}
