package paquete.tratamientoPack;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import paquete.cultivoPack.Cultivo;
import paquete.prodFitoPack.Producto;

public interface TratamientoRepository extends JpaRepository<Tratamiento, Long> {
 
	List<Tratamiento> findByFecha(LocalDate fecha);
	List<Tratamiento> findByReentrada(LocalDate fecha);
	List<Tratamiento> findByRecoleccion(LocalDate fecha);
	List<Tratamiento> findByCultivoEspecie(String especie);
	List<Tratamiento> findByProductoNombre(String nombre);
	List<Tratamiento> findByFechaLessThanEqualAndReentradaGreaterThanEqualOrFechaLessThanEqualAndRecoleccionGreaterThanEqualOrderByReentrada(LocalDate fecha,LocalDate fecha1,LocalDate fecha2,LocalDate fecha3);
	List<Tratamiento> findByFechaLessThanEqualAndReentradaGreaterThanEqualOrFechaLessThanEqualAndRecoleccionGreaterThanEqualOrderByCultivoEspecie(LocalDate fecha,LocalDate fecha1,LocalDate fecha2,LocalDate fecha3);
	List<Tratamiento> findByFechaLessThanEqualAndReentradaGreaterThanEqualOrFechaLessThanEqualAndRecoleccionGreaterThanEqualOrderByRecoleccion(LocalDate fecha,LocalDate fecha1,LocalDate fecha2,LocalDate fecha3);
}
