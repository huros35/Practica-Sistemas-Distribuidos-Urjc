package paquete.prodFitoPack;



import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;




@Controller
public class ProdFitoController {
	@Autowired
	private ProdFitoRepository repositorioProductos;
	@PostConstruct
	   public void init() {
	    }
	@RequestMapping("/insertarProducto")
	public String insertar(Producto producto,Model model) {
		repositorioProductos.save(producto);

		return "productos/insertarProducto";
	
	}
	@RequestMapping("/modificarProducto")
	public String modificar(@RequestParam long idproducto,Producto producto, Model model) {
		Producto p = repositorioProductos.getOne(idproducto);
		p.updateProd(producto);
		repositorioProductos.save(p);

		return "productos/modificarProducto";
	}
	
	@RequestMapping("/actualizarProducto")
	public String actualizar(@RequestParam long idproducto,
						   Model model) {
		Producto p = repositorioProductos.getOne(idproducto);
		model.addAttribute("producto",p);

		return "productos/actualizarProducto";
	}
	@RequestMapping("/mostrarProductos")
	public String mostrar(  Model model) {
		
		List<Producto> listaproductos = repositorioProductos.findAll();

	    model.addAttribute("productos", listaproductos);
		

		return "productos/mostrarProductos";
	}
	@RequestMapping("/buscarProducto")
	public String buscar( @RequestParam String consulta,@RequestParam String buscar, Model model) {
		List<Producto> listaproductos = null ;
		if (consulta.equals("nombre")){
			listaproductos = repositorioProductos.findByNombre(buscar);
	    }else if(consulta.equals("plazo reentrada")) {
	    	listaproductos = repositorioProductos.findByReentrada(Integer.parseInt(buscar));

	        	
	    }else {
	    	listaproductos = repositorioProductos.findByRecoleccion(Integer.parseInt(buscar));
	    }
		
		model.addAttribute("productos", listaproductos);
		return "productos/mostrarProductos";
	}
}
