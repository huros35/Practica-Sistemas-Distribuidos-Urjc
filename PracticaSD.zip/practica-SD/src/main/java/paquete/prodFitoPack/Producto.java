package paquete.prodFitoPack;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import paquete.tratamientoPack.Tratamiento;





@Entity
public class Producto {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long idproducto;
	String nombre;
	String descripcion;
	int reentrada;
	int recoleccion;
	
	public Producto() {
		
	}
	public Producto(String nombre, String descripcion, int reentrada, int recoleccion) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.reentrada = reentrada;
		this.recoleccion = recoleccion;
	}
	public void updateProd(Producto p) {
		this.nombre=p.getNombre();
		this.descripcion=p.getDescripcion();
		this.reentrada=p.getReentrada() ;
		this.recoleccion=p.getRecoleccion();
	}
	
	public long getIdproducto() {
		return idproducto;
	}
	public String getNombre() {
		return nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public int getReentrada() {
		return reentrada;
	}
	public int getRecoleccion() {
		return recoleccion;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public void setReentrada(int reentrada) {
		this.reentrada = reentrada;
	}
	public void setRecoleccion(int recoleccion) {
		this.recoleccion = recoleccion;
	}
	
	@Override
	public String toString() {
		return "Producto [Nombre="+nombre+"]";
	}
	
	
	
}
