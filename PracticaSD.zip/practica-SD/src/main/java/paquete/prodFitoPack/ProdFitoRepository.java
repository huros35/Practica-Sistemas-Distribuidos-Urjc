package paquete.prodFitoPack;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;



public interface ProdFitoRepository extends JpaRepository<Producto, Long>{
	
	List<Producto> findByNombre(String nombre);
	List<Producto> findByReentrada(int num);
	List<Producto> findByRecoleccion(int num);
}
